import random
kuji = ["大吉", "中吉", "小吉", "凶"]
print(random.choice(kuji))