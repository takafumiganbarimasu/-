b = "こんにちは"
print(int(b)+23)
