a = "100"
print(a+23)
