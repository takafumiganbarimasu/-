import tax

print(tax.postTaxPrice(120),"円")
print(tax.postTaxPrice(128),"円")
print(tax.postTaxPrice(980),"円")
