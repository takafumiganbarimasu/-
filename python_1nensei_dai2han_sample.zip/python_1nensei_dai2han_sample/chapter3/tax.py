def postTaxPrice(price):
    ans = price * 1.1
    return ans
