scorelist = [64, 100, 78, 80, 72]
for i in scorelist:
    print(i)
