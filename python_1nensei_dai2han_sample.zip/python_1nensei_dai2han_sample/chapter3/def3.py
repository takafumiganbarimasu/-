def sayhello2(name):
    print("こんにちは、"+ name + "さん。")
sayhello2("フタバ")