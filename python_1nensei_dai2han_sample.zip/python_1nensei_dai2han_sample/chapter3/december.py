import calendar 
print(calendar.month(2022,12))
